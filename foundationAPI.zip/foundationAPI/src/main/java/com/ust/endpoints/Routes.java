package com.ust.endpoints;

public class Routes {
	
		public static String getUri_unique="/52";
		public static String baseuri="http://localhost:8081/trainee";
		public static String get_basePath="/all";
		public static String getUnique="/{id}";
		public static String post_basePath="/trainees";
		public static String put_basePath="/trainees/{id}";
		public static String patch_basepath="/trainees/{id}";
		public static String delete_basepath="/trainees/{id}";
	
}
