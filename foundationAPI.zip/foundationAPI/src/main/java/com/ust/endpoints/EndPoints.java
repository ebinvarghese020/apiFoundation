package com.ust.endpoints;

import com.ust.payload.STModel;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;


public class EndPoints {

	public static Response create(STModel payload) {
	    Response response = RestAssured.given()
	            .baseUri(Routes.baseuri)
	            .basePath(Routes.post_basePath)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();

	    return response;
	}
	
	public static Response createJsonPayload(String payload) {
	    Response response = RestAssured.given()
	            .baseUri(Routes.baseuri)
	            .basePath(Routes.post_basePath)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();

	    return response;
	}
	
	public static Response getAll() {
	    Response response = RestAssured.given()
	            .baseUri(Routes.baseuri)
	            .basePath(Routes.get_basePath)
	            .contentType("application/json")
	            .accept(ContentType.JSON)
	            .when()
	            .get();

	    return response;
	}
	
	public static Response getOne(int id) {
	    Response response = RestAssured.given()
	            .baseUri(Routes.baseuri)
	            .basePath(Routes.getUnique)
	            .pathParam("id", id)
	            .contentType("application/json")
	            .accept(ContentType.JSON)
	            .when()
	            .get();

	    return response;
	}
	
	
	public static Response putUser(long id,STModel payload) {
		Response response = RestAssured.given()
							.baseUri(Routes.baseuri)
							.basePath(Routes.put_basePath)
							.pathParam("id", id)
							.contentType("application/json")
							.accept(ContentType.JSON)
   							.body(payload)
   							.when()
							.put();
		return response;
	}
	
	
	public static Response patchUser(long id,STModel payload) {
		Response response = RestAssured.given()
							.baseUri(Routes.baseuri)
							.basePath(Routes.put_basePath)
							.pathParam("id", id)
							.contentType("application/json")
							.accept(ContentType.JSON)
   							.body(payload)
   							.when()
							.put();
		return response;
	}
	
	public static Response delete(int id) {
	    Response response = RestAssured.given()
	            .baseUri(Routes.baseuri)
	            .basePath(Routes.delete_basepath)
				.pathParam("id", id)
	            .contentType("application/json")
	            .accept(ContentType.JSON)
	            .when()
	            .delete();

	    return response;
	}
}
