package karateTest;

import org.testng.annotations.Listeners;

import com.intuit.karate.junit5.Karate;

@Listeners(com.ust.utilities.ExtentReportManager.class)
public class JUnit5Runner {
    // Disable SSL certificate validation
    static {
        System.setProperty("karate.ssl.disabled", "true"); // disable SSL certificate validation
    }
    
    // Define a Karate test
    @Karate.Test
    Karate karateTest() {
        // Run the feature file located at 'src/test/resources/karateTest/apiTest.feature'
        return Karate.run("classpath:karateTest/apiTest.feature").relativeTo(getClass());
    }
}