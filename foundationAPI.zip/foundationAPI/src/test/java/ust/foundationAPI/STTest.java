package ust.foundationAPI;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.testng.Assert.assertEquals;

import java.io.File;

import org.hamcrest.Matchers;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.endpoints.EndPoints;
import com.ust.endpoints.Routes;
import com.ust.payload.STModel;

import io.restassured.RestAssured;
import io.restassured.response.Response;

@Listeners(com.ust.utilities.ExtentReportManager.class)
public class STTest {
	
//	Test method for get single person details
	@Test(priority=1)
	public void getOnlyOne() {
		RestAssured.useRelaxedHTTPSValidation();
		STModel team=new STModel(6);
		Response response=EndPoints.getOne(team.getId());
		response.then().log().all()
		.body("id", Matchers.is(6))
		.body("name",Matchers.is("gautam"))
		.assertThat().statusLine("HTTP/1.1 200 ");
		assertEquals(response.getStatusCode(), 200);
		assertEquals(response.getContentType(),"application/json");
	}
	
//	Test method for get list
	@Test(priority=2)
	public void getAll() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response=EndPoints.getAll();
		response.then().log().all()
		.assertThat().statusLine("HTTP/1.1 200 ");;
		assertEquals(response.getStatusCode(), 200);
		assertEquals(response.getContentType(),"application/json");
	}
	
////	Test method for post
	@Test(priority=3)
	public void post() {
		RestAssured.useRelaxedHTTPSValidation();
		STModel one=new STModel("akbar","abu","akbar@gmail.com","tvm");
		Response response=EndPoints.create(one);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}	

//	Test method for delete
	@Test(priority=7)
	public void delete() {
		RestAssured.useRelaxedHTTPSValidation();
		STModel team=new STModel(157);
		Response response=EndPoints	.delete(team.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
//	Test method for validating json schema for get single person
	@Test(priority=8)
    public void schemaValidation() {
	 RestAssured.useRelaxedHTTPSValidation();
	 RestAssured.given()
	 	.baseUri(Routes.baseuri)
		.basePath(Routes.getUri_unique)
	    .when()
	    .get()
	    .then()
	    .assertThat()
	    .body(matchesJsonSchema(new File(System.getProperty("user.dir")+"/src/test/resources/schema.json")));
	}
}